====================================================
  KRCT CAMPUS LOST & FOUND SYSTEM
  Setup & Run Guide
====================================================

STEP 1 — Install Python 3
  Windows: https://www.python.org/downloads/
  Make sure to check "Add Python to PATH" during install.

STEP 2 — Open Terminal / Command Prompt
  Windows: Press Win+R, type cmd, press Enter
  Mac/Linux: Open Terminal

STEP 3 — Navigate to this folder
  cd path\to\lostfound

STEP 4 — Install required packages (one-time)
  pip install flask flask-mail flask-socketio flask-login werkzeug

STEP 5 — Set up Gmail App Password
  a) Go to: https://myaccount.google.com/security
  b) Enable 2-Step Verification (if not already)
  c) Go to: https://myaccount.google.com/apppasswords
  d) Create app password for "Mail" → Copy the 16-character password
  e) Open app.py and replace:
       app.config['MAIL_PASSWORD'] = 'YOUR_APP_PASSWORD_HERE'
     with:
       app.config['MAIL_PASSWORD'] = 'xxxx xxxx xxxx xxxx'
     (your 16-char app password)

STEP 6 — Run the app
  python app.py

STEP 7 — Open browser
  Go to: http://localhost:5000

====================================================
DEFAULT ADMIN LOGIN:
  Email:    admin@krct.ac.in
  Password: admin123
====================================================

FEATURES:
  - Student registration with college email + roll number
  - Report lost / found items with images
  - Auto smart-matching when item is reported
  - Gmail email notifications to nivetha.al23@krct.ac.in
  - Real-time chat between students (SocketIO)
  - Claim submission + admin approval
  - Admin panel with full analytics

WORKS FULLY OFFLINE (no internet needed EXCEPT for Gmail SMTP)
====================================================
