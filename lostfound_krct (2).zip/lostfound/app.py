from flask import Flask, render_template, request, redirect, url_for, flash, jsonify, session, send_from_directory
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, logout_user, login_required, current_user
from flask_mail import Mail, Message
from flask_socketio import SocketIO, emit, join_room
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
from datetime import datetime
from functools import wraps
import os, re

app = Flask(__name__)
app.config['SECRET_KEY'] = 'krct-lostfound-secret-2024'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///lostfound.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['MAX_CONTENT_LENGTH'] = 5 * 1024 * 1024

app.config['MAIL_SERVER']   = 'smtp.gmail.com'
app.config['MAIL_PORT']     = 587
app.config['MAIL_USE_TLS']  = True
app.config['MAIL_USERNAME'] = 'nivetha.al23@krct.ac.in'
app.config['MAIL_PASSWORD'] = 'YOUR_APP_PASSWORD_HERE'
app.config['MAIL_DEFAULT_SENDER'] = ('KRCT Lost & Found', 'nivetha.al23@krct.ac.in')

ALLOWED_EXT = {'png','jpg','jpeg','gif','webp'}
CATEGORIES  = ['ID Card','Phone','Bag / Backpack','Wallet','Keys','Laptop','Bottle','Stationery','Clothing','Other']
LOCATIONS   = ['Library','Canteen','Main Block','Lab Block','Hostel','Parking','Auditorium','Sports Ground','Admin Office','Other']

db        = SQLAlchemy(app)
mail      = Mail(app)
login_mgr = LoginManager(app)
socketio  = SocketIO(app)
login_mgr.login_view = 'login'

def allowed(f): return '.' in f and f.rsplit('.',1)[1].lower() in ALLOWED_EXT

# ---------- Models ----------

class User(UserMixin, db.Model):
    id         = db.Column(db.Integer, primary_key=True)
    name       = db.Column(db.String(100), nullable=False)
    email      = db.Column(db.String(120), unique=True, nullable=False)
    roll_no    = db.Column(db.String(30),  unique=True, nullable=False)
    password   = db.Column(db.String(256), nullable=False)
    role       = db.Column(db.String(10),  default='student')
    created_at = db.Column(db.DateTime,    default=datetime.utcnow)

class Item(db.Model):
    id            = db.Column(db.Integer, primary_key=True)
    title         = db.Column(db.String(150), nullable=False)
    description   = db.Column(db.Text, nullable=False)
    category      = db.Column(db.String(50), nullable=False)
    location      = db.Column(db.String(80), nullable=False)
    item_type     = db.Column(db.String(10), nullable=False)
    status        = db.Column(db.String(15), default='open')
    image         = db.Column(db.String(200))
    date_reported = db.Column(db.DateTime,   default=datetime.utcnow)
    user_id       = db.Column(db.Integer,    db.ForeignKey('user.id'), nullable=False)
    approved      = db.Column(db.Boolean,    default=True)
    reporter      = db.relationship('User',  backref='items', foreign_keys=[user_id])

class Match(db.Model):
    id           = db.Column(db.Integer, primary_key=True)
    item_id      = db.Column(db.Integer, db.ForeignKey('item.id'), nullable=False)
    matched_id   = db.Column(db.Integer, db.ForeignKey('item.id'), nullable=False)
    score        = db.Column(db.Float,   default=0.0)
    created_at   = db.Column(db.DateTime, default=datetime.utcnow)
    matched_item = db.relationship('Item', foreign_keys=[matched_id])

class ChatMessage(db.Model):
    id          = db.Column(db.Integer, primary_key=True)
    item_id     = db.Column(db.Integer, db.ForeignKey('item.id'), nullable=False)
    sender_id   = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    receiver_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    message     = db.Column(db.Text, nullable=False)
    timestamp   = db.Column(db.DateTime, default=datetime.utcnow)
    read        = db.Column(db.Boolean,  default=False)
    sender      = db.relationship('User', foreign_keys=[sender_id])
    receiver    = db.relationship('User', foreign_keys=[receiver_id])

class Notification(db.Model):
    id         = db.Column(db.Integer, primary_key=True)
    user_id    = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    message    = db.Column(db.String(300), nullable=False)
    link       = db.Column(db.String(200))
    read       = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

@login_mgr.user_loader
def load_user(uid): return User.query.get(int(uid))

def admin_required(f):
    @wraps(f)
    def dec(*a,**k):
        if not current_user.is_authenticated or current_user.role != 'admin':
            flash('Admin access required.','danger')
            return redirect(url_for('dashboard'))
        return f(*a,**k)
    return dec

# ---------- Email ----------

def send_email(to, subject, html):
    try:
        m = Message(subject, recipients=[to]); m.html = html; mail.send(m)
    except Exception as e:
        print(f'[Mail] {e}')

def email_match(lost, found):
    lu = User.query.get(lost.user_id); fu = User.query.get(found.user_id)
    for u, other in [(lu, found), (fu, lost)]:
        html = f"""<div style="font-family:Arial;max-width:520px;margin:auto;border:1px solid #ddd;border-radius:8px">
        <div style="background:#185FA5;padding:20px;color:#fff"><h2 style="margin:0">KRCT Lost &amp; Found</h2></div>
        <div style="padding:24px"><p>Hi <b>{u.name}</b>, a possible match was found!</p>
        <table style="width:100%;border-collapse:collapse"><tr style="background:#f5f5f5">
        <th style="padding:8px;text-align:left">Lost item</th><th style="padding:8px;text-align:left">Found item</th></tr>
        <tr><td style="padding:8px;border:1px solid #eee">{lost.title}<br><small>{lost.category} · {lost.location}</small></td>
            <td style="padding:8px;border:1px solid #eee">{found.title}<br><small>{found.category} · {found.location}</small></td></tr></table>
        <p><a href="http://localhost:5000/item/{lost.id}">Click here to view and chat</a></p>
        <p style="color:#888;font-size:12px">KRCT Lost &amp; Found automated alert</p></div></div>"""
        send_email(u.email, f'[KRCT L&F] Match found: {lost.title}', html)

def email_message(receiver, sender, item):
    html = f"""<div style="font-family:Arial;max-width:520px;margin:auto;border:1px solid #ddd;border-radius:8px">
    <div style="background:#185FA5;padding:20px;color:#fff"><h2 style="margin:0">KRCT Lost &amp; Found</h2></div>
    <div style="padding:24px"><p>Hi <b>{receiver.name}</b>,</p>
    <p><b>{sender.name}</b> sent you a message about <b>{item.title}</b>.</p>
    <p><a href="http://localhost:5000/item/{item.id}">Login to reply</a></p></div></div>"""
    send_email(receiver.email, f'[KRCT L&F] New message from {sender.name}', html)

# ---------- Matching ----------

STOP = {'the','a','an','in','on','at','was','is','my','i','it','and','or','of','to','this','with','near'}

def match_score(a, b):
    score = 0.0
    if a.category == b.category: score += 40
    if a.location  == b.location:  score += 25
    wa = set(re.findall(r'\w+', (a.title+' '+a.description).lower())) - STOP
    wb = set(re.findall(r'\w+', (b.title+' '+b.description).lower())) - STOP
    if wa and wb:
        score += (len(wa & wb) / max(len(wa | wb),1)) * 35
    return round(score, 1)

def run_matching(new_item):
    opposite = 'found' if new_item.item_type == 'lost' else 'lost'
    candidates = Item.query.filter_by(item_type=opposite, status='open', approved=True).all()
    best_score, best = 0, None
    for c in candidates:
        if c.id == new_item.id: continue
        s = match_score(new_item, c)
        if s >= 50:
            if not Match.query.filter_by(item_id=new_item.id, matched_id=c.id).first():
                db.session.add(Match(item_id=new_item.id, matched_id=c.id, score=s))
            if s > best_score: best_score, best = s, c
    db.session.commit()
    if best:
        lost  = new_item if new_item.item_type == 'lost' else best
        found = best if new_item.item_type == 'lost' else new_item
        email_match(lost, found)
        for uid in [lost.user_id, found.user_id]:
            db.session.add(Notification(user_id=uid,
                message=f'Possible match found for "{lost.title}"!',
                link=url_for('item_detail', item_id=lost.id)))
            socketio.emit('new_notif', {'msg': f'Match found for "{lost.title}"!'}, room=str(uid))
        db.session.commit()

# ---------- Auth ----------

@app.route('/')
def index():
    return redirect(url_for('dashboard') if current_user.is_authenticated else url_for('login'))

@app.route('/login', methods=['GET','POST'])
def login():
    if current_user.is_authenticated: return redirect(url_for('dashboard'))
    if request.method == 'POST':
        u = User.query.filter_by(email=request.form['email'].strip().lower()).first()
        if u and check_password_hash(u.password, request.form['password']):
            login_user(u); return redirect(url_for('dashboard'))
        flash('Invalid email or password.','danger')
    return render_template('login.html')

@app.route('/register', methods=['GET','POST'])
def register():
    if request.method == 'POST':
        name  = request.form['name'].strip()
        email = request.form['email'].strip().lower()
        roll  = request.form['roll_no'].strip().upper()
        pwd   = request.form['password']
        if not email.endswith('@krct.ac.in'):
            flash('Only @krct.ac.in emails allowed.','danger')
            return render_template('register.html')
        if User.query.filter_by(email=email).first():
            flash('Email already registered.','danger'); return render_template('register.html')
        if User.query.filter_by(roll_no=roll).first():
            flash('Roll number already registered.','danger'); return render_template('register.html')
        db.session.add(User(name=name,email=email,roll_no=roll,password=generate_password_hash(pwd)))
        db.session.commit()
        send_email(email,'Welcome to KRCT Lost & Found',
            f'<p>Hi {name}, your account is active. <a href="http://localhost:5000/login">Login here</a>.</p>')
        flash('Registered successfully! Please log in.','success')
        return redirect(url_for('login'))
    return render_template('register.html')

@app.route('/logout')
@login_required
def logout(): logout_user(); return redirect(url_for('login'))

# ---------- Main ----------

@app.route('/dashboard')
@login_required
def dashboard():
    q   = request.args.get('q','').strip()
    cat = request.args.get('category','')
    loc = request.args.get('location','')
    typ = request.args.get('type','')
    qry = Item.query.filter_by(approved=True)
    if q:   qry = qry.filter(db.or_(Item.title.ilike(f'%{q}%'), Item.description.ilike(f'%{q}%')))
    if cat: qry = qry.filter_by(category=cat)
    if loc: qry = qry.filter_by(location=loc)
    if typ: qry = qry.filter_by(item_type=typ)
    items  = qry.order_by(Item.date_reported.desc()).all()
    unread = Notification.query.filter_by(user_id=current_user.id, read=False).count()
    return render_template('dashboard.html', items=items, categories=CATEGORIES,
                           locations=LOCATIONS, unread=unread,
                           q=q, sel_cat=cat, sel_loc=loc, sel_type=typ)

@app.route('/report', methods=['GET','POST'])
@login_required
def report():
    if request.method == 'POST':
        img = None
        f   = request.files.get('image')
        if f and f.filename and allowed(f.filename):
            fn = secure_filename(f.filename)
            f.save(os.path.join(app.config['UPLOAD_FOLDER'], fn)); img = fn
        item = Item(title=request.form['title'].strip(),
                    description=request.form['description'].strip(),
                    category=request.form['category'],
                    location=request.form['location'],
                    item_type=request.form['item_type'],
                    image=img, user_id=current_user.id)
        db.session.add(item); db.session.commit()
        run_matching(item)
        flash(f'Your {item.item_type} item has been reported!','success')
        return redirect(url_for('dashboard'))
    return render_template('report.html', categories=CATEGORIES, locations=LOCATIONS)

@app.route('/item/<int:item_id>')
@login_required
def item_detail(item_id):
    item    = Item.query.get_or_404(item_id)
    matches = Match.query.filter_by(item_id=item_id).order_by(Match.score.desc()).all()
    msgs    = ChatMessage.query.filter_by(item_id=item_id).order_by(ChatMessage.timestamp).all()
    ChatMessage.query.filter_by(item_id=item_id, receiver_id=current_user.id, read=False).update({'read':True})
    db.session.commit()
    other_user = None
    if item.user_id != current_user.id:
        other_user = User.query.get(item.user_id)
    elif matches:
        m_item = matches[0].matched_item
        other_user = User.query.get(m_item.user_id) if m_item else None
    return render_template('item_detail.html', item=item, matches=matches,
                           messages=msgs, other_user=other_user)

@app.route('/item/<int:item_id>/claim', methods=['POST'])
@login_required
def claim_item(item_id):
    item = Item.query.get_or_404(item_id)
    item.status = 'claimed'; db.session.commit()
    send_email(item.reporter.email, f'[KRCT L&F] Item claimed: {item.title}',
        f'<p>Your item <b>{item.title}</b> has been marked as claimed. Great news!</p>')
    flash('Item marked as claimed.','success')
    return redirect(url_for('item_detail', item_id=item_id))

@app.route('/my-items')
@login_required
def my_items():
    items = Item.query.filter_by(user_id=current_user.id).order_by(Item.date_reported.desc()).all()
    return render_template('my_items.html', items=items)

@app.route('/notifications')
@login_required
def notifications():
    notifs = Notification.query.filter_by(user_id=current_user.id).order_by(Notification.created_at.desc()).all()
    Notification.query.filter_by(user_id=current_user.id, read=False).update({'read':True})
    db.session.commit()
    return render_template('notifications.html', notifs=notifs)

# ---------- Admin ----------

@app.route('/admin')
@login_required
@admin_required
def admin_panel():
    return render_template('admin.html',
        users=User.query.order_by(User.created_at.desc()).all(),
        items=Item.query.order_by(Item.date_reported.desc()).all(),
        total_lost=Item.query.filter_by(item_type='lost').count(),
        total_found=Item.query.filter_by(item_type='found').count(),
        claimed=Item.query.filter_by(status='claimed').count(),
        total_users=User.query.count())

@app.route('/admin/toggle/<int:item_id>')
@login_required
@admin_required
def toggle_approve(item_id):
    i = Item.query.get_or_404(item_id); i.approved = not i.approved
    db.session.commit(); return redirect(url_for('admin_panel'))

@app.route('/admin/delete-item/<int:item_id>')
@login_required
@admin_required
def delete_item(item_id):
    db.session.delete(Item.query.get_or_404(item_id)); db.session.commit()
    flash('Item deleted.','success'); return redirect(url_for('admin_panel'))

@app.route('/admin/toggle-admin/<int:user_id>')
@login_required
@admin_required
def toggle_admin(user_id):
    u = User.query.get_or_404(user_id)
    u.role = 'student' if u.role == 'admin' else 'admin'
    db.session.commit(); return redirect(url_for('admin_panel'))

# ---------- SocketIO ----------

@socketio.on('join')
def on_join(data): join_room(str(current_user.id))

@socketio.on('send_msg')
def handle_msg(data):
    rid  = int(data['receiver_id'])
    text = data['message'].strip()
    if not text: return
    msg = ChatMessage(item_id=int(data['item_id']), sender_id=current_user.id,
                      receiver_id=rid, message=text)
    db.session.add(msg)
    db.session.add(Notification(user_id=rid,
        message=f'New message from {current_user.name}',
        link=url_for('item_detail', item_id=data['item_id'])))
    db.session.commit()
    payload = {'sender': current_user.name, 'message': text,
               'time': msg.timestamp.strftime('%H:%M')}
    emit('recv_msg', payload, room=str(rid))
    emit('recv_msg', payload, room=str(current_user.id))
    emit('new_notif', {'msg': f'Message from {current_user.name}'}, room=str(rid))
    receiver = User.query.get(rid)
    item     = Item.query.get(int(data['item_id']))
    email_message(receiver, current_user, item)

@app.route('/uploads/<filename>')
def uploaded_file(filename): return send_from_directory(app.config['UPLOAD_FOLDER'], filename)

# ---------- Boot ----------

def create_admin():
    if not User.query.filter_by(role='admin').first():
        db.session.add(User(name='Admin', email='nivetha.al23@krct.ac.in',
            roll_no='ADMIN001', password=generate_password_hash('admin123'), role='admin'))
        db.session.commit()
        print('  Admin: nivetha.al23@krct.ac.in | password: admin123')

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
        create_admin()
    print('\n  KRCT Lost & Found running at http://localhost:5000\n')
    socketio.run(app, debug=True, host='0.0.0.0', port=5000)
